export const githubToken = "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";

export const firebaseConfig = {
  apiKey: "AIzaSyAzKB647kZFG3ybKrtAfwGU7mB_nFtqVR8",
  authDomain: "candlelight-7eaee.firebaseapp.com",
  projectId: "candlelight-7eaee",
  storageBucket: "candlelight-7eaee.appspot.com",
  messagingSenderId: "657211434270",
  appId: "1:657211434270:web:e36ae03b2e6503bfb1550f",
  measurementId: "G-PEEHKT2F04"
};

export const redirect_uri_pro="exp://u.expo.dev/update/f2b40542-8870-4c52-8369-b4e89740b91d/"
export const redirect_uri_dev="exp://192.168.100.81:19000"
