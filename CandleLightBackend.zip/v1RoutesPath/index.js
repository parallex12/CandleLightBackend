import Users from "../routes/Users.js";

export const v1Routes = [
  { path: "/users", file: Users },
];
